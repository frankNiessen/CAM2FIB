function gCode2streamFile
%% gCode2streamFile.m
% Script for execution of g-code file to coordinate list translation 
% (gCode2toolPath.m) and writing of a stream file pattern file as an input
% to an FEI dual-beam Helios microscope
% *************************************************************************
% Copyright (c) 2018, Frank Niessen, EMC, AIIM, University of Wollongong
% All rights reserved
% Permission is hereby granted, free of charge, to any person obtaining a 
% copy of this software and associated documentation files (the "Software"),
% to deal in the Software without restriction, including without limitation
% the rights to use, copy, modify, merge, publish, distribute, sublicense, 
% and/or sell copies of the Software, and to permit persons to whom the 
% Software is furnished to do so, subject to the following conditions:
% The above copyright notice and this permission notice shall be included 
% in all copies or substantial portions of the Software.
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
% OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
% MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
% *************************************************************************
close all
clc
fprintf('\n*********** Executing gCode2streamFile.m ****************\n');
fprintf(['\nConversion of g-code to interpolated coordinates for writing ',...
         'stream pattern file as an input to FEI Helios DualBeam\n']);
%% Initialization
fprintf('\n-> Initializing ***');
% *** File Input settings *************************************************
[f.Name,f.Path] = uigetfile('Input_Gfiles\*.*','Select a G-code file');    % Select G-Code file
fNameFull = [f.Path,'\',f.Name];                                           % Assemble full filename
f.lengthUnit = 1e-9;                                                       % Conversion factor from input unit (usually [m]) to streamfile unit (usually [nm])
% *** Interpolation settings **********************************************
interpRes.dist = 5;                                                        % Distance resolution in input length unit
interpRes.ang = 1;                                                         % Angular resolution in degree
% *** Streamfile output settings ******************************************
str.DAC = 's16';                                                           % Digital Analog Converter (DAC) type ['s16': DAC is 16 bits]
str.nrIter = 1;                                                            % Nr of iterations for pattern
str.millTime = [20 40 60 80 100];                             % Pattern milling time [s] / Multiple milling times possible [x y z ...]
str.fType = 'str';                                                         % File extension
% *** Scaling parameters - Patterning-Imaging-Acquisition *****************
PIA.rot = 180;                                                              % Pattern rotation [deg]
PIA.flip = [0 1];                                                          % Flag: Flip [x y]
PIA.cal = 314;                                                             % Bits per �m per 1k Mag.
PIA.max = [65536 56576];                                                   % Adressable max x and y range of Patterning-Imaging-Acquisition
PIA.AR = PIA.max(2)/PIA.max(1);                                            % PIA aspect ratio
PIA.relScale = 0.25;                                                       % Reduction factor relative to maximum pattering range [0 to 1]
PIA.centerPattern = 1;                                                     % Flag: Center pattern in Pattering range
PIA.availMags = [.1e3 .5e3  1e3  2e3  5e3  10e3  20e3  30e3  40e3 ...  
                50e3 60e3];                                                % Available magnifications
% *** Visual Output Options ***********************************************
Out.scrPrint = 0;                                                          % Flag: Screen print
Out.plot = 1;                                                              % Flag: Plotting output
Out.scatter = 1;                                                           % Flag: Scatter points instead of lines
Out.plotCnt = 50;                                                          %Nr of plots for live plot
%% Calculate and scale toolPath
% *** Convert g-code to toolpath ******************************************
[toolPath,BB] = gCode2toolPath(fNameFull,interpRes.dist,...
                             interpRes.ang,Out,f);                         % Interpolate toolpath from gCode
[toolPath,str] = scaleToolPath(toolPath,PIA,f,str,Out);                    % Scale toolPath
tileFigs();
drawnow;
%% Output
for i=1:length(str.millTime)
    fprintf('\n-> Writing streamfile %.0f s: %.0f of %.0f ***',str.millTime(i),i,length(str.millTime));
    strFilePath = writeStreamFile(toolPath,BB,str,f,str.millTime(i));      % Write stream pattern file
end
fprintf('\n***********  All done!  ***********');
end
%% Read in gCode file
function out = readGfile(filename, startRow, endRow)
% *** Initialize variables ************************************************
delimiter = ' ';
if nargin<=2
    startRow = 1;
    endRow = inf;
end
% *** Open the text file **************************************************
formatSpec = '%s%s%s%s%s%s%s%[^\n\r]';
fileID = fopen(filename,'r');
% *** Read columns of data according to the format ************************
dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'EmptyValue' ,NaN,'HeaderLines', startRow(1)-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
for block=2:length(startRow)
    frewind(fileID);
    dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'EmptyValue' ,NaN,'HeaderLines', startRow(block)-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');
    for col=1:length(dataArray)
        dataArray{col} = [dataArray{col};dataArrayBlock{col}];
    end
end
% *** Close the text file and create output variable **********************
fclose(fileID);
out = [dataArray{1:end-1}];
end
%% Interpolate toolPath from gCode  commands
function [toolPath,BB] = gCode2toolPath(fName,dRes,angRes,Out,f)
%function toolPath = gCode2toolPath(fName,dRes,angRes,Out,f)
% Read in of g-code file and output of interpolated tool path cooredinates 
% for a given distance and angular resolution
% fName:    File name, either relative to current folder or including
%           absolutepath
% dRes:     Distance resolution in input unit
% angRes:   Angular resolution in degree
% scrPrint: Screen output
% toolPath: x, y, and z coordinate list of interpolated toolpath
% ************************************************************************
% This code curently supports commands G0, G1, G2 and G3 for rapid 
% movement, rapid cordinated movement, clockwise arc move and counter 
% clockwise arc move
% ************************************************************************
% Adapted from an initial version by Tom Williamson (18/06/2018)
% [https://mathworks.com/matlabcentral/fileexchange/67767-g-code-reader]
% Original copyrright:
% Copyright (c) 2018, Tom Williamson
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 
% * Redistributions of source code must retain the above copyright notice, this
%   list of conditions and the following disclaimer.
% 
% * Redistributions in binary form must reproduce the above copyright notice,
%   this list of conditions and the following disclaimer in the documentation
%   and/or other materials provided with the distribution
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

% *** Ini *****************************************************************
fprintf('\n-> Interpreting g-code ***');
absIJ = 0;                                                                 %Absolute [1] or relative [0] coordinates I and J for arc center of G2 and G3
preAllocFac = 10;                                                          %Preallocation factor for output array
dcrit = 50;                                                                %Minimum distance for 'G0' beam blanked movements (leave empty '[]' if no threshould should be applied)
% Initialize variables
k = 1;                                                                     %ToolPath counter
curMode = NaN;                                                             %Current mode
newPos = [0,0,0];                                                          %newPosition
interpPos = [];                                                            %Interpolated positions
bbCor = [];                                                                %Coordinates of beam blanked points
% ******************************** READ OUT *******************************
rawFile = readGfile(fName);                                                %Read in g-code file
toolPath = NaN(preAllocFac*length(rawFile),3);                             %Allocate memory for toolPath
BB = ones(preAllocFac*length(rawFile),1);                                  %Initialize beam blanking flag array
% Plotting
if Out.plot; [h] = plotPattern([],[],[],f,'Ini',Out); end                  %Initialize Plot
% ******************************** Interpret g-code ***********************
for row = 1:length(rawFile)
    fullLine = rawFile(row,:);                                             %Get line
    fullLine = fullLine(~cellfun(@isempty,fullLine));                      %Remove empty line fragments
    if strcmp(fullLine{1}(1),'N')                                          %Continue if line is no instruction line
         fullLine = fullLine(2:end);
    end
    arcOffsets = [0,0,0];                                                  %Reset arcOffsets
    for i = 1:length(fullLine)                                             %Loop over line fragments
        if Out.scrPrint; disp(fullLine{i}); end                            %Screen print
        switch fullLine{i}                                                 %Check for commands G0 - G3 
            case 'G0' %Rapid Positioning
                if Out.scrPrint; disp('Rapid positioning'); end
                curMode = 'G0';
            case 'G1' %Linear Interpolation
                if Out.scrPrint; disp('Linear interpolation'); end
                curMode = 'G1';
            case 'G2' %Controlled Arc Move, clockwise
                if Out.scrPrint; disp('Controlled Arc Move, clockwise'); end
                curMode = 'G2';                    
            case 'G3' %Controlled Arc Move, counterclockwise
                if Out.scrPrint; disp('Controlled Arc Move, counterclockwise'); end
                curMode = 'G3';         
            otherwise
                switch fullLine{i}(1)                                      %Check for coordinates X, Y, Z, I, J
                    case 'X'
                        newPos(1) = str2double(fullLine{i}(2:end));
                    case 'Y'
                        newPos(2) = str2double(fullLine{i}(2:end));
                    case 'Z'
                        newPos(3) = str2double(fullLine{i}(2:end));                            
                    case 'I'
                        arcOffsets(1) = str2double(fullLine{i}(2:end));
                    case 'J'
                        arcOffsets(2) = str2double(fullLine{i}(2:end));
                end
         end
    end
% ******************************** Interpolate coordinates ****************
% G0: Rapid positioning ******************************************
    switch curMode
        case 'G0'
            if k ==1
                interpPos = newPos;
                BB(k:k+size(interpPos,1)-1,:) = 0;
            else
                dist = norm((newPos - toolPath(k-1,:)));
                if isempty(dcrit) || dist > dcrit
                    interpPos = newPos;
                    BB(k:k+size(interpPos,1)-1,:) = 0;
                    if [any(contains(fullLine,'X'))|| any(contains(fullLine,'Y'))]
                       bbCor = [bbCor;toolPath(k-1,:);interpPos];
                    end
                else
                    direction = (newPos - toolPath(k-1,:))/dist;
                    interpPos = toolPath(k-1,:) + direction.*(0:dRes:dist)';
                    interpPos = [interpPos;newPos];
                end
            end
% G1: Linear interpolation ******************************************
        case 'G1'
            %Determine distance of linear movement
            dist = norm((newPos - toolPath(k-1,:)));
            if dist > 0 %if distance is non-zero compute refined interpolation
                direction = (newPos - toolPath(k-1,:))/dist;
                interpPos = toolPath(k-1,:) + direction.*(0:dRes:dist)';
                interpPos = [interpPos;newPos];
            end
    % Path: Clockwise circle interpolation ****************************
        case 'G2'
            if absIJ
                cntrPos = arcOffsets;                                      %Absolute center position of Arc I J
            else
                cntrPos = toolPath(k-2,:) + arcOffsets;                      %Relative center position of Arc I J  
            end
            v1 = (toolPath(k-1,1:2)-cntrPos(1:2));
            v2 = (newPos(1:2)-cntrPos(1:2));            
            r = norm(newPos(1:2)-cntrPos(1:2));
            ang(1) = atan2d(v1(2),v1(1));
            ang(2) = atan2d(v2(2),v2(1));

            if ang(2) > ang(1)
                ang(2) = ang(2)-360;
            end
            interpPos = [cntrPos(1:2) + [cosd(ang(1):-angRes:ang(2))',sind(ang(1):-angRes:ang(2))']*r, linspace(cntrPos(3),newPos(3),length(ang(1):-angRes:ang(2)))'];
            interpPos = [interpPos;newPos];
    % Path: Counterclockwise circle interpolation *************************
        case 'G3'
            if absIJ
                cntrPos = arcOffsets;                                      %Absolute center position of Arc I J
            else
                cntrPos = toolPath(k-1,:) + arcOffsets;                      %Relative center position of Arc I J  
            end
            v1 = (toolPath(k-1,1:2)-cntrPos(1:2));                           %First vector
            v2 = (newPos(1:2)-cntrPos(1:2));                               %Second vector
            r = norm(v2);                                                  %Radius
            ang(1) = atan2d(v1(2),v1(1));
            ang(2) = atan2d(v2(2),v2(1));
            if norm(v1) <0.1
                ang(1) = 0;
            end
            if norm(v2) <0.1
                ang(2) = 0;
            end            
            if ang(2) < ang(1)
                ang(2) = ang(2)+360;
            end
            interpPos = [cntrPos(1:2) + [cosd(ang(1):angRes:ang(2))',sind(ang(1):angRes:ang(2))']*r, linspace(cntrPos(3),newPos(3),length(ang(1):angRes:ang(2)))'];
            interpPos = [interpPos;newPos];
    end
    % Update variables and plots ******************************************
    toolPath(k:k+size(interpPos,1)-1,:) = interpPos;                       %Update toolpath
    k = k + size(interpPos,1);                                             %Update counter
    if Out.plot && ~mod(row,Out.plotCnt)
       h = plotPattern(h,toolPath(:,1),toolPath(:,2),f,'Update');
    end
    % Reallocate memory ***************************************************
    if k > 0.5*length(toolPath)
       toolPath = [toolPath;NaN(ceil(0.5*preAllocFac*length(rawFile)),3)]; %Allocate memory for toolPath
       BB = [BB;ones(ceil(0.5*preAllocFac*length(rawFile)),1)];            %Initialize beam blanking flag array
    end
end
% *** Create machining strategy plot **************************************
if Out.plot
    h = plotPattern(h,toolPath(1:k,1),toolPath(1:k,2),f,'Surf',BB,bbCor);
    saveImgs(h,f);
    drawnow;
end
% *** Output **************************************************************
aNind = ~all(isnan(toolPath),2);                                           %Find NaN rows
toolPath = toolPath(aNind,:);                                              %Delete all NaN rows
BB = BB(aNind);                                                            %Delete all NaN rows
end
%% Plot patterns
function [h] = plotPattern(h,X,Y,f,mode,varargin)
switch mode
    case 'Ini'
        Out = varargin{1};
        h.fig = figure('units','normalized','outerposition',[0.1 0.1 0.9 0.9]);%Create figure
        h.ax(1) = subplot(1,2,1);                                              %Create axes
        title(h.ax(1),'Live View');
        set(h.ax(1),'Parent',h.fig,'Color','k');                               %Create axes
        hold on;
        if Out.scatter
            h.plt = scatter(h.ax(1),NaN,NaN,1,'w');  
        else
            h.plt = plot(h.ax(1),NaN,NaN,'w');
        end
        daspect([1 1 1]);
        xlabel(h.ax(1),['x [',num2str(f.lengthUnit,'%1.0e'),' m]']);
        ylabel(h.ax(1),['y [',num2str(f.lengthUnit,'%1.0e'),' m]']);
    case 'Update'
        set(h.plt,'XData',X,'YData',Y);
        drawnow;
    case 'Surf'
        h.fig;
        h.ax(2) = subplot(1,2,2);                                          %Create axes
        title(h.ax(2),'Machining strategy');
        set(h.ax(2),'Parent',h.fig,'Color','k');                           %Create axes
        k = size(X,1);
        BB = varargin{1};
        bbCor = varargin{2};
        bbTemp = BB(1:k);                                                         
        X = [X,X];
        Y = [Y,Y];
        Z = [zeros(k,1),zeros(k,1)];
        C = [1:k;1:k]';
        X(bbTemp==0,:) = nan; Y(bbTemp==0,:) = nan; Z(bbTemp==0) = nan;
        surface(h.ax(2),X,Y,Z,C,'facecol','no','edgecol','interp','linew',2);
        colormap('jet');
        h.c = colorbar;
        ylabel(h.c,'Pattering order [1]');
        daspect(h.ax(2),[1 1 1]);
        xlabel(h.ax(2),['x [',num2str(f.lengthUnit,'%1.0e'),' m]']);
        ylabel(h.ax(2),['y [',num2str(f.lengthUnit,'%1.0e'),' m]']);
        hold on
        for i = 1:2:size(bbCor,1)
            plot(bbCor(i:i+1,1),bbCor(i:i+1,2),'w:','linewidth',2);
        end
   case 'Density'
        figure;
        h.ax(3) = axes('Color','k');
        hist3(h.ax(3),[X,Y],[50 50],'CDataMode','auto','FaceColor','interp','EdgeColor','none');
        c(1) = colorbar(h.ax(3));
        colormap(c(1),'jet');
        view(h.ax(3),2);
        set(h.ax(3),'Ydir','reverse','Color','k');
        daspect(h.ax(3),[1 1 1]);
        xlabel(h.ax(3),'DAC-pts X [1]'); ylabel(h.ax(3),'DAC-pts Y [1]');
        title(h.ax(3),'Point density map');
   case 'Scaled' 
        Out = varargin{1};
        figure;
        h.ax(4) = axes('Color','k');
        if Out.scatter
            scatter(h.ax(4),X,Y,1,'w');  
        else
            plot(h.ax(4),X,Y,'w');
        end
        set(h.ax(4),'Ydir','reverse','Color','k');
        daspect([1 1 1]);
        xlabel('DAC-pts X [1]'); ylabel('DAC-pts Y [1]');
        title('Scaled ToolPath');
end
end
%% Save images
function saveImgs(h,f)
%function saveImgs(h)

if ~isdir(['images\',f.Name])
    mkdir(['images\',f.Name]);
end
for i = 1:length(h.ax)
    hfig(i) = figure('visible','off','renderer','opengl','invertHardcopy','off',...
                     'units','inch','outerposition',[1,1,6,6],'color','w');
    hax_new(i) = copyobj(h.ax(i), hfig(i));
    set(hax_new(i), 'Position', get(0, 'DefaultAxesPosition'));
    title(hax_new(i),'');
    if i==2
        colormap('jet');
        h.c = colorbar;
        ylabel(h.c,'Pattering order [1]');
    end
    print(hfig(i),['images\',f.Name,'\SF',num2str(i),'.tiff'],'-dtiff','-r300');
end
end
%% Scale toolPath
function [toolPath,str] = scaleToolPath(toolPath,PIA,f,str,Out)
fprintf('\n-> Scaling toolpath ***');
toolPath = toolPath(:,1:2);                                                % Discard z-coordinates
R=[cosd(PIA.rot) -sind(PIA.rot); sind(PIA.rot) cosd(PIA.rot)];             % Create rptation matrix
toolPath = toolPath*R';                                                    % Rotate toolpath
if PIA.flip(1); toolPath(:,2) = -1*(toolPath(:,2)-max(toolPath(:,2))); end
if PIA.flip(2); toolPath(:,1) = -1*(toolPath(:,1)-max(toolPath(:,1))); end
patternSz = (max(toolPath)-min(toolPath))*f.lengthUnit;                    % Get pattern size in m
maxMag = min(min(PIA.max)./ (patternSz * 1e6 * PIA.cal)*1e3);              % Find maximum magnification for fitting pattern on screen
str.patMag = PIA.availMags(max(find(maxMag * PIA.relScale > PIA.availMags))); % Find suitable magnification for pattering
toolPath = toolPath.*f.lengthUnit.*1e6.*PIA.cal.*str.patMag.*1e-3;         % Convert toolPath to bits
toolPath = toolPath - min(toolPath);                                       % Anquer at 0
if PIA.centerPattern
    toolPath = toolPath + 0.5*(PIA.max-max(toolPath));                     % Centre
end
if Out.plot
    h = plotPattern([],toolPath(:,1),toolPath(:,2),f,'Density');
    h = plotPattern(h,toolPath(:,1),toolPath(:,2),f,'Scaled',Out);
    drawnow;
end
end
%% Write stream file
function fNameFull = writeStreamFile(toolPath,BB,settings,fInfo,t)
%function strFilePath = writeStreamFile(toolPath,settings,fileInfo)
%*** Prepare matrix format ************************************************
nrLines = size(toolPath,1);                                                %Nr of coordinate lines
dwTime = round(t/nrLines*1e7,-1);                                          %Calculate dwell time
toolPath = [repmat(dwTime,nrLines,1),toolPath,BB];                         %Add dwell time and BeamBlank flag
toolPath(end+1,:) = [toolPath(end,1:end-1),0];                             %Add beam blank line to the end of file
%*** Write header *********************************************************
if ~isdir(['Output_StreamFiles\',fInfo.Name])
    mkdir(['Output_StreamFiles\',fInfo.Name]);
end
fNameFull = ['Output_StreamFiles\',fInfo.Name,'\',...
              num2str(settings.patMag),'xMag_',num2str(t),'s.',settings.fType]; 
fID = fopen(fNameFull,'w');
fprintf(fID, '%s\n%s\n%s\n', settings.DAC, num2str(settings.nrIter),...
        num2str(nrLines+1));                                               % Write header
fclose(fID);
dlmwrite(fNameFull,toolPath,'delimiter','\t','precision','%1.0f',...
         'newline','unix','-append');
end

%% tileFigs - Tile figures accross screen
function tileFigs() 
%function tileFigs() 
%Tile all figures evenly spread accros the screen
%% Initialization
mon = 1;                                                                   %Choose monitor number
offset.l = 70; offset.r = 0; offset.b = 70; offset.t = 0;                  %Offsets left right botton top (possible taskbars)
grid = [2 2 2 2 2 3 3 3 3 3 3 4 4 4 4 4 4 4 4 4; 
3 3 3 3 3 3 3 3 4 4 4 5 5 5 5 5 5 5 5 6]';                                 %Define figure grid
%% Find figures and screen dimension
h.figs = flip(findobj('type','figure'));                                   %Get figure handles
set(h.figs,'unit','pixels');                                               %Set figure units to [pxs]
nFigs = size(h.figs,1);                                                    %Get number of figures

scr.Sz = get(0,'MonitorPositions');                                        %Get screen size
scr.h = scr.Sz(mon,4)-offset.t;                                            %Get screen height
scr.w = scr.Sz(mon,3)-offset.l-offset.r;                                   %Get screen width
scr.orX = scr.Sz(mon,1)+offset.l;                                          %Get screen origin X
scr.orY = scr.Sz(mon,2);                                                   %Get screen origin Y
%% Check limits
if ~nFigs; error('figures are not found'); return; end                     %Stop for no figures
if nFigs > 20; error('too many figures(maximum = 20)'); return; end        %Check for limit of 20 figures
%% Define grid according to screen aspect ratio
if scr.w > scr.h %Widescreen
    n.h = grid(nFigs,1);                                                   %Define number of figures in height                                                 
    n.w = grid(nFigs,2);                                                   %Define number of figures in width         
else 
    n.h = grid(nFigs,2);                                                   %Define number of figures in height 
    n.w = grid(nFigs,1);                                                   %Define number of figures in width  
end 
%% Determine height and width for each figure
fig.h = (scr.h-offset.b)/n.h;                                              %Figure height
fig.w =  scr.w/n.w;                                                        %Figure width
%% Resize figures
k = 1;                                                                     %Initialize figure counter
for i =1:n.h %Loop over height
    for j = 1:n.w  %Loop over width
        if k > nFigs; return; end                                          %Stop when all figures have been resized 
        fig_pos = [scr.orX + fig.w*(j-1) scr.h-fig.h*i fig.w fig.h];   %Compute new figure position 
        set(h.figs(k),'OuterPosition',fig_pos);                            %Set new figure position
        k = k + 1;                                                         %Increase figure counter
    end 
end
end