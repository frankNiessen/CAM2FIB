function toolPath = gCodeReaderFRANK(filepath, dist_res, angRes, plotPath, scrPrint)
%gCodeReader  Function that takes a G-Code file and outputs the tool path 
% for plotting/analysis. Not a complete analysis of the whole file, but 
% more or less the basic motions. 
% Inputs: 
%        - path to G-Code file
%        - point spacing for linear motion (mm or inches, I guess)
%        - point spacing for arc motion (degrees)
%        - Plot the current path (1 or 0)
%        - Output raw G-Code to console
% Outputs:
%        - The interpolated tool path
% Notes:
%        - This is not at all complete, but should work well enough for
%        simple CNC G-Code. If you need anything more complex, I'd suggest
%        you implement it yourself, as this was more or less all I needed
%        at the time.
%        - I have also done zero optimization.
%        - This comes with no guarantees or warranties whatsoever, but I
%        hope it's useful for someone.
% 
% Example usage:
%       toolpath = gCodeReader('simplePart.NC',0.5,0.5,1,0);
% 
% Tom Williamson
% 18/06/2018
close all
clc
%% Ini
absIJ = 1;                                                                 %Absolute [1] or relative [0] I and J for arc center of G2 and G3
dwellTime = 10;                                                            %Dwelltime [x100 ns]
preAllocFac = 10;                                                          %Preallocated lines for toolPath (x times lineNr of input file)
% Modes
G0 = 0; G1 = 1; G2 = 2; G3 = 3;
% Plotting
livePlot = 1;                                                              %2D live-plot on or off [1 0]
plotCnt = 1000;                                                            %Plotting interval [int]
% Initialize variables
curMode = NaN;                                                             %Current mode
newPos = [0,0,0];
arcOffsets = [0,0,0];
interpPos = [];
%% ReadOut and interpolation
% ******************************** READ OUT *******************************
rawFile = readGfile(filepath);
toolPath = NaN(length(rawFile)*preAllocFac,3);
if livePlot 
    h.fig = figure;                                                        %Create figure
    h.ax = axes('Parent',h.fig);                                           %Create axes
    hold on;
    h.plt = plot(NaN,NaN,'k');
end
for row = 1:length(rawFile)
    fullLine = rawFile(row,:);                                             %Get line
    fullLine = fullLine(~cellfun(@isempty,fullLine));                      %Remove empty line fragments
    if ~strcmp(fullLine{1}(1),'N')                                         %Continue if line is no instruction line
        continue
    end
    arcOffsets = [0,0,0];                                                  %Reset arcOffsets
    for i = 2:length(fullLine)                                             %Loop over line fragments
        if scrPrint; disp(fullLine{i}); end                                %Screen print
        switch fullLine{i}                                                 %Check for commands G0 - G3 
            case 'G0' %Rapid Positioning
                if scrPrint; disp('Rapid positioning'); end
                curMode = G0;
            case 'G1' %Linear Interpolation
                if scrPrint; disp('Linear interpolation'); end
                curMode = G1;
            case 'G2' %Controlled Arc Move, clockwise
                if scrPrint; disp('Controlled Arc Move, clockwise'); end
                curMode = G2;                    
            case 'G3' %Controlled Arc Move, counterclockwise
                if scrPrint; disp('Controlled Arc Move, counterclockwise'); end
                curMode = G3;         
            otherwise
                switch fullLine{i}(1)                                      %Check for coordinates X, Y, Z, I, J
                    case 'X'
                        newPos(1) = str2double(fullLine{i}(2:end));
                    case 'Y'
                        newPos(2) = str2double(fullLine{i}(2:end));
                    case 'Z'
                        newPos(3) = str2double(fullLine{i}(2:end));                            
                    case 'I'
                        arcOffsets(1) = str2double(fullLine{i}(2:end));
                    case 'J'
                        arcOffsets(2) = str2double(fullLine{i}(2:end));
                end
         end
    end
% ******************************** INTERPOLATION **************************
% G0: Rapid positioning ******************************************
    switch curMode
        case G0
            interpPos = [NaN NaN NaN;newPos];
% G1: Linear interpolation ******************************************
        case G1
            %Determine distance of linear movement
            dist = norm((newPos - toolPath(end,:)));
            if dist > 0 %if distance is non-zero compute refined interpolation
                direction = (newPos - toolPath(end,:))/dist;
                interpPos = toolPath(end,:) + direction.*(0:dist_res:dist)';
                interpPos = [interpPos;newPos];
            end
    % Path: Clockwise circle interpolation ****************************
        case G2
            if absIJ
                cntrPos = arcOffsets;                                      %Absolute center position of Arc I J
            else
                cntrPos = toolPath(end,:) + arcOffsets;                    %Relative center position of Arc I J  
            end
            v1 = (toolPath(end,1:2)-cntrPos(1:2));
            v2 = (newPos(1:2)-cntrPos(1:2));            
            r = norm(newPos(1:2)-cntrPos(1:2));
            ang(1) = atan2d(v1(2),v1(1));
            ang(2) = atan2d(v2(2),v2(1));

            if ang(2) > ang(1)
                ang(2) = ang(2)-360;
            end
            interpPos = [cntrPos(1:2) + [cosd(ang(1):-angRes:ang(2))',sind(ang(1):-angRes:ang(2))']*r, linspace(cntrPos(3),newPos(3),length(ang(1):-angRes:ang(2)))'];
            interpPos = [interpPos;newPos];
    % Path: Counterclockwise circle interpolation ****************************
        case G3
            if absIJ
                cntrPos = arcOffsets;                                      %Absolute center position of Arc I J
            else
                cntrPos = toolPath(end,:) + arcOffsets;                    %Relative center position of Arc I J  
            end
            v1 = (toolPath(end,1:2)-cntrPos(1:2));                         %First vector
            v2 = (newPos(1:2)-cntrPos(1:2));                               %Second vector
            r = norm(v2);                                                  %Radius
            ang(1) = atan2d(v1(2),v1(1));
            ang(2) = atan2d(v2(2),v2(1));
            if norm(v1) <0.1
                ang(1) = 0;
            end
            if norm(v2) <0.1
                ang(2) = 0;
            end            
            if ang(2) < ang(1)
                ang(2) = ang(2)+360;
            end
            interpPos = [cntrPos(1:2) + [cosd(ang(1):angRes:ang(2))',sind(ang(1):angRes:ang(2))']*r, linspace(cntrPos(3),newPos(3),length(ang(1):angRes:ang(2)))'];
            interpPos = [interpPos;newPos];
    end
    toolPath = [toolPath;interpPos];
    if livePlot && ~mod(row,plotCnt)
        set(h.plt,'XData',toolPath(:,1),'YData',toolPath(:,2))
        drawnow;
    end
end

% Plot if requested
if plotPath
    figure;
    plot3(toolPath(:,1),toolPath(:,2),toolPath(:,3),'r-')
end
