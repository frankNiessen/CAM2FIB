function toolPath = gCode2toolPath(fName,dRes,angRes,scrPrint,plotOut)
%function toolPath = gCode2toolPath(fName,dRes,angRes,plotPath,scrPrint)
% Read in of g-code file and output of interpolated tool path cooredinates 
% for a given distance and angular resolution
% fName:    File name, either relative to current folder or including
%           absolutepath
% dRes:     Distance resolution in input unit
% angRes:   Angular resolution in degree
% scrPrint: Screen output
% toolPath: x, y, and z coordinate list of interpolated toolpath
% ************************************************************************
% This code curently supports commands G0, G1, G2 and G3 for rapid 
% movement, rapid cordinated movement, clockwise arc move and counter 
% clockwise arc move
% ************************************************************************
% Copyright Frank Niessen, EMC, AIIM, University of Wollongong, 11/2018
% Based on an initial version by Tom Williamson (18/06/2018)
% [https://mathworks.com/matlabcentral/fileexchange/67767-g-code-reader]
%% Ini
absIJ = 1;                                                                 %Absolute [1] or relative [0] I and J for arc center of G2 and G3
preAllocFac = 5;                                                           %Preallocated lines for toolPath (x times lineNr of input file)
% Modes
G0 = 0; G1 = 1; G2 = 2; G3 = 3;                                            %Mode indexing
% Plotting
plotCnt = 100;                                                             %Plotting interval [int]
% Initialize variables
k = 1;                                                                     %ToolPath counter
curMode = NaN;                                                             %Current mode
newPos = [0,0,0];                                                          %newPosition
interpPos = [];                                                            %Interpolated positions
%% ReadOut and interpolation
% ******************************** READ OUT *******************************
rawFile = readGfile(fName);
toolPath = NaN(length(rawFile)*preAllocFac,3);
if plotOut 
    h.fig = figure;                                                        %Create figure
    h.ax = axes('Parent',h.fig);                                           %Create axes
    hold on;
    h.plt = plot(NaN,NaN,'k');
end
for row = 1:length(rawFile)
    fullLine = rawFile(row,:);                                             %Get line
    fullLine = fullLine(~cellfun(@isempty,fullLine));                      %Remove empty line fragments
    if ~strcmp(fullLine{1}(1),'N')                                         %Continue if line is no instruction line
        continue
    end
    arcOffsets = [0,0,0];                                                  %Reset arcOffsets
    for i = 2:length(fullLine)                                             %Loop over line fragments
        if scrPrint; disp(fullLine{i}); end                                %Screen print
        switch fullLine{i}                                                 %Check for commands G0 - G3 
            case 'G0' %Rapid Positioning
                if scrPrint; disp('Rapid positioning'); end
                curMode = G0;
            case 'G1' %Linear Interpolation
                if scrPrint; disp('Linear interpolation'); end
                curMode = G1;
            case 'G2' %Controlled Arc Move, clockwise
                if scrPrint; disp('Controlled Arc Move, clockwise'); end
                curMode = G2;                    
            case 'G3' %Controlled Arc Move, counterclockwise
                if scrPrint; disp('Controlled Arc Move, counterclockwise'); end
                curMode = G3;         
            otherwise
                switch fullLine{i}(1)                                      %Check for coordinates X, Y, Z, I, J
                    case 'X'
                        newPos(1) = str2double(fullLine{i}(2:end));
                    case 'Y'
                        newPos(2) = str2double(fullLine{i}(2:end));
                    case 'Z'
                        newPos(3) = str2double(fullLine{i}(2:end));                            
                    case 'I'
                        arcOffsets(1) = str2double(fullLine{i}(2:end));
                    case 'J'
                        arcOffsets(2) = str2double(fullLine{i}(2:end));
                end
         end
    end
% ******************************** INTERPOLATION **************************
% G0: Rapid positioning ******************************************
    switch curMode
        case G0
            interpPos = [NaN NaN NaN;newPos];
% G1: Linear interpolation ******************************************
        case G1
            %Determine distance of linear movement
            dist = norm((newPos - toolPath(k-1,:)));
            if dist > 0 %if distance is non-zero compute refined interpolation
                direction = (newPos - toolPath(k-1,:))/dist;
                interpPos = toolPath(k-1,:) + direction.*(0:dRes:dist)';
                interpPos = [interpPos;newPos];
            end
    % Path: Clockwise circle interpolation ****************************
        case G2
            if absIJ
                cntrPos = arcOffsets;                                      %Absolute center position of Arc I J
            else
                cntrPos = toolPath(k-1,:) + arcOffsets;                      %Relative center position of Arc I J  
            end
            v1 = (toolPath(k-1,1:2)-cntrPos(1:2));
            v2 = (newPos(1:2)-cntrPos(1:2));            
            r = norm(newPos(1:2)-cntrPos(1:2));
            ang(1) = atan2d(v1(2),v1(1));
            ang(2) = atan2d(v2(2),v2(1));

            if ang(2) > ang(1)
                ang(2) = ang(2)-360;
            end
            interpPos = [cntrPos(1:2) + [cosd(ang(1):-angRes:ang(2))',sind(ang(1):-angRes:ang(2))']*r, linspace(cntrPos(3),newPos(3),length(ang(1):-angRes:ang(2)))'];
            interpPos = [interpPos;newPos];
    % Path: Counterclockwise circle interpolation ****************************
        case G3
            if absIJ
                cntrPos = arcOffsets;                                      %Absolute center position of Arc I J
            else
                cntrPos = toolPath(k-1,:) + arcOffsets;                      %Relative center position of Arc I J  
            end
            v1 = (toolPath(k-1,1:2)-cntrPos(1:2));                           %First vector
            v2 = (newPos(1:2)-cntrPos(1:2));                               %Second vector
            r = norm(v2);                                                  %Radius
            ang(1) = atan2d(v1(2),v1(1));
            ang(2) = atan2d(v2(2),v2(1));
            if norm(v1) <0.1
                ang(1) = 0;
            end
            if norm(v2) <0.1
                ang(2) = 0;
            end            
            if ang(2) < ang(1)
                ang(2) = ang(2)+360;
            end
            interpPos = [cntrPos(1:2) + [cosd(ang(1):angRes:ang(2))',sind(ang(1):angRes:ang(2))']*r, linspace(cntrPos(3),newPos(3),length(ang(1):angRes:ang(2)))'];
            interpPos = [interpPos;newPos];
    end
    toolPath(k:k+size(interpPos,1)-1,:) = interpPos;
    k = k + size(interpPos,1);
    if plotOut && ~mod(row,plotCnt)
        set(h.plt,'XData',toolPath(:,1),'YData',toolPath(:,2))
        drawnow;
    end
end

%% Output
toolPath = toolPath(~all(isnan(toolPath),2),:);                            %Delete all NaN rows
